﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Data.SqlClient;
using System.Linq;
using System.Windows.Forms;
using WindowsFormsApp2;

namespace UnitTestProject
{
    [TestClass]
    public class Form1Tests
    {
        private Form1 form1;
        private string connectionString = @"Data Source=DESKTOP-MGDIAP6; Initial catalog=agents; Integrated Security=True";

        [TestInitialize]
        public void TestInitialize()
        {
            form1 = new Form1();
            form1.Show(); // Открытие формы перед каждым тестом
        }

        [TestMethod]
        public void TestSignIn_SuccessfulLogin_ShowsMainForm()
        {
            // Arrange
            var validEmail = "ivanov@mail.com"; // Учётные данные из базы данных
            var validPassword = "password123";    // Соответствующий пароль

            var form1 = new Form1();
            form1.SetConnectionString("Data Source=DESKTOP-MGDIAP6; Initial catalog=agents; Integrated Security=True");
            form1.textBox1.Text = validEmail;
            form1.textBox2.Text = validPassword;

            // Act
            form1.signin_Click(this, EventArgs.Empty);

            // Assert
            var mainForm = Application.OpenForms.OfType<MainForm>().FirstOrDefault(); // Получаем открывшуюся форму MainForm
            Assert.IsNotNull(mainForm); // Убедитесь, что MainForm открыта
            Assert.AreEqual("Админ", mainForm.TypeUser); // Проверьте установленное значение (роль)
        }
        [TestMethod]
        public void TestSignIn_InvalidCredentials_ShowsErrorMessage()
        {
            // Arrange
            form1.textBox1.Text = "invalid_email@example.com";  // Эмулируем неправильный email
            form1.textBox2.Text = "incorrect_password";         // Эмулируем неправильный пароль

            // Act
            form1.signin_Click(null, null);  // Вызываем клик по кнопке

            // Assert
            // Проверяем, что появляется сообщение об ошибке
            var result = MessageBox.Show("Пользователь не найден.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            Assert.AreEqual(DialogResult.OK, result);
        }

        [TestMethod]
        public void TestSignIn_ValidCredentials_CallsExecuteScalar()
        {
            // Arrange
            form1.textBox1.Text = "ivanov@mail.com";
            form1.textBox2.Text = "password123";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT Роль FROM Пользователи WHERE Email = @email AND Пароль = @password";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@email", form1.textBox1.Text);
                command.Parameters.AddWithValue("@password", form1.textBox2.Text);

                connection.Open();
                object result = command.ExecuteScalar();
                connection.Close();

                // Act
                form1.signin_Click(null, null);  // Вызываем клик по кнопке

                // Assert
                Assert.IsNotNull(result);  // Проверяем, что SQL-запрос вернул не null
            }
        }

        [TestMethod]
        public void TestSignIn_ShowsErrorMessageIfNoConnection()
        {
            // Arrange
            form1.textBox1.Text = "ivanov@mail.com";
            form1.textBox2.Text = "password123";

            // Прерывание соединения
            string invalidConnectionString = @"Data Source=INVALID_SERVER; Initial catalog=agents; Integrated Security=True";
            form1.SetConnectionString(invalidConnectionString);

            // Act & Assert
            try
            {
                form1.signin_Click(null, null);  // Вызываем клик по кнопке
                Assert.Fail("Expected exception due to invalid connection");
            }
            catch (SqlException)
            {
                Assert.IsTrue(true); // Ожидаем исключение
            }
        }

        [TestMethod]
        public void TestSignIn_ShowsLinkToRegistrationForm()
        {
            // Arrange
            var linkLabel = new LinkLabel();
            linkLabel.Text = "Зарегистрироваться";
            linkLabel.LinkClicked += form1.linkLabel1_LinkClicked; // Привязываем обработчик события

            // Создаем объект события LinkLabelLinkClickedEventArgs
            var eventArgs = new LinkLabelLinkClickedEventArgs(linkLabel.Links[0]);

            // Act
            // Вручную вызываем обработчик события
            form1.linkLabel1_LinkClicked(linkLabel, eventArgs);

            // Assert
            // Проверка, что открылся Form2
            Assert.IsTrue(Application.OpenForms.OfType<Form2>().Any());
        }

        [TestMethod]
        public void TestTextBoxEmail_IsEmpty_ShouldShowError()
        {
            // Arrange
            form1.textBox1.Text = string.Empty;  // Пустое поле email
            form1.textBox2.Text = "correct_password";

            // Act
            form1.signin_Click(null, null);  // Вызываем клик по кнопке

            // Assert
            var result = MessageBox.Show("Email cannot be empty.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            Assert.AreEqual(DialogResult.OK, result);
        }

        [TestMethod]
        public void TestTextBoxPassword_IsEmpty_ShouldShowError()
        {
            // Arrange
            form1.textBox1.Text = "ivanov@mail.com";
            form1.textBox2.Text = string.Empty;  // Пустое поле пароля

            // Act
            form1.signin_Click(null, null);  // Вызываем клик по кнопке

            // Assert
            var result = MessageBox.Show("Password cannot be empty.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            Assert.AreEqual(DialogResult.OK, result);
        }

        [TestMethod]
        public void TestSignIn_ConnectionStringTest_ThrowsExceptionIfInvalid()
        {
            // Arrange
            form1.textBox1.Text = "ivanov@mail.com";
            form1.textBox2.Text = "password123";

            // Имитируем невалидную строку подключения
            string invalidConnectionString = @"Data Source=INVALID_SERVER; Initial catalog=agents; Integrated Security=True";
            form1.SetConnectionString(invalidConnectionString);

            // Act & Assert
            try
            {
                form1.signin_Click(null, null);  // Вызываем клик по кнопке
                Assert.Fail("Expected SqlException due to invalid connection");
            }
            catch (SqlException)
            {
                Assert.IsTrue(true); // Ожидаем исключение
            }
        }

        [TestMethod]
        public void TestSignIn_EmptyCredentials_ShouldShowErrorMessages()
        {
            // Arrange
            form1.textBox1.Text = string.Empty;  // Пустое поле email
            form1.textBox2.Text = string.Empty;  // Пустое поле пароля

            // Act
            form1.signin_Click(null, null);  // Вызываем клик по кнопке

            // Assert
            var resultEmail = MessageBox.Show("Email cannot be empty.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            var resultPassword = MessageBox.Show("Password cannot be empty.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            Assert.AreEqual(DialogResult.OK, resultEmail);
            Assert.AreEqual(DialogResult.OK, resultPassword);
        }

        [TestMethod]
        public void TestSignIn_AnotherValidCredentials_ShowsMainForm()
        {
            // Arrange
            var validEmail = "petrova@mail.com"; // Учётные данные из базы данных
            var validPassword = "password456";    // Соответствующий пароль

            var form1 = new Form1();
            form1.SetConnectionString("Data Source=DESKTOP-MGDIAP6; Initial catalog=agents; Integrated Security=True");
            form1.textBox1.Text = validEmail;
            form1.textBox2.Text = validPassword;

            // Act
            form1.signin_Click(this, EventArgs.Empty);

            // Assert
            var mainForm = Application.OpenForms.OfType<MainForm>().FirstOrDefault(); // Получаем открывшуюся форму MainForm
            Assert.IsNotNull(mainForm); // Убедитесь, что MainForm открыта
            Assert.AreEqual("Агент", mainForm.TypeUser); // Проверьте установленное значение (роль)
        }
    }
}
