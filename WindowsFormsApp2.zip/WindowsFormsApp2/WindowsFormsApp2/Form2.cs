﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace WindowsFormsApp2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Email = textBox3.Text;
            string newPassword = textBox1.Text;
            string confirmPassword = textBox2.Text;

            if (newPassword != confirmPassword)
            {
                MessageBox.Show("Пароли не совпадают.");
                return;
            }

            string query = "UPDATE Пользователи SET Пароль = @Пароль WHERE Email = @Email";

            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(@"Data Source=DESKTOP-MGDIAP6;Initial Catalog=agents;Integrated Security=True"))
                {
                    SqlCommand command = new SqlCommand(query, sqlConnection);
                    command.Parameters.AddWithValue("@Email", Email);
                    command.Parameters.AddWithValue("@Пароль", newPassword);

                    sqlConnection.Open();
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Пароль успешно изменен.");
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Пользователь не найден.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }
    }
}
