﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public string TypeUser { get; set; }

        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection sqlConnection = new SqlConnection(@" Data Source= DESKTOP-MGDIAP6; Initial catalog=agents; Integrated Security=True");

        private void signin_Click(object sender, EventArgs e)
        {
            string emaill = textBox1.Text;
            string passwordd = textBox2.Text;

            string query = "SELECT Роль FROM Пользователи WHERE Email = @email AND Пароль = @password";

            using (sqlConnection)
            {
                SqlCommand command = new SqlCommand(query, sqlConnection);
                command.Parameters.Add("@email", SqlDbType.NVarChar).Size = 50;
                command.Parameters["@email"].Value = emaill;

                command.Parameters.Add("@password", SqlDbType.NVarChar).Size = 50;
                command.Parameters["@password"].Value = passwordd;
                sqlConnection.Open();

                object result = command.ExecuteScalar();

                if (result != null && result != DBNull.Value)
                {

                    string type = result.ToString().Trim();
                    MainForm MainForm = new MainForm();
                    MainForm.TypeUser = type; // Присваиваем значение свойству Type

                    MessageBox.Show("Пользователь найден. Тип пользователя: " + type);
                    MainForm.Show();

                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Пользователь не найден.");
                    Application.Exit();
                }
                sqlConnection.Close();
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {            
            Form2 frm = new Form2();
            frm.Show();
        }
    }
}
