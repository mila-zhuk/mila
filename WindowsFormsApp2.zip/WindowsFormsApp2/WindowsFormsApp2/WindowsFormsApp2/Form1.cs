﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public string TypeUser { get; set; }

        private string connectionString = @"Data Source=DESKTOP-MGDIAP6; Initial catalog=agents; Integrated Security=True";

        public SqlConnection SqlConnection => new SqlConnection(connectionString);

        public Form1()
        {
            InitializeComponent();
        }

        public void signin_Click(object sender, EventArgs e)
        {
            string emaill = textBox1.Text;
            string passwordd = textBox2.Text;

            if (string.IsNullOrEmpty(emaill))
            {
                MessageBox.Show("Email cannot be empty.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (string.IsNullOrEmpty(passwordd))
            {
                MessageBox.Show("Password cannot be empty.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string query = "SELECT Роль FROM Пользователи WHERE Email = @email AND Пароль = @password";

            using (SqlConnection sqlConnection = SqlConnection)
            {
                SqlCommand command = new SqlCommand(query, sqlConnection);
                command.Parameters.Add("@email", SqlDbType.NVarChar).Size = 50;
                command.Parameters["@email"].Value = emaill;

                command.Parameters.Add("@password", SqlDbType.NVarChar).Size = 50;
                command.Parameters["@password"].Value = passwordd;

                sqlConnection.Open();

                object result = command.ExecuteScalar();

                if (result != null && result != DBNull.Value)
                {
                    string type = result.ToString().Trim();
                    MainForm MainForm = new MainForm();
                    MainForm.TypeUser = type; // Присваиваем значение свойству Type

                    MessageBox.Show("Пользователь найден. Тип пользователя: " + type);
                    MainForm.Show();

                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Пользователь не найден.");
                    Application.Exit();
                }

                sqlConnection.Close();
            }
        }

        public void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form2 frm = new Form2();
            frm.Show();
        }

        // Добавляем метод для установки строки подключения
        public void SetConnectionString(string connectionString)
        {
            this.connectionString = connectionString;
        }
    }
}
