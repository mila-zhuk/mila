﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }
        public string TypeUser { get; set; }

        private void button1_Click(object sender, EventArgs e)
        {
              AddNewObject frm = new AddNewObject();
              frm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (TypeUser == "Админ") // Замените на реальное название роли администратора
            {
                Users usersForm = new Users();
                usersForm.Show();
            }
            else
            {
                MessageBox.Show("У вас нет доступа к этой функции.");
            }
        }
    }
}
