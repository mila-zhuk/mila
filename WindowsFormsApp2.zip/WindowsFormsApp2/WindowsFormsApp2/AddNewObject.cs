﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class AddNewObject : Form
    {
        public AddNewObject()
        {
            InitializeComponent();
            LoadAgents(); // Load agents into comboBox5 when the form initializes
            Add.Click += new EventHandler(Add_Click); // Attach the event handler for the Add button
        }
        SqlConnection sqlConnection = new SqlConnection(@" Data Source= DESKTOP-MGDIAP6; Initial catalog=agents; Integrated Security=True");

        private void LoadAgents()
        {
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(@"Data Source=DESKTOP-MGDIAP6;Initial Catalog=agents;Integrated Security=True"))
                {
                    sqlConnection.Open();
                    SqlCommand command = new SqlCommand("SELECT ID, Имя, Фамилия FROM Пользователи WHERE Роль = 'Агент'", sqlConnection);
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        int id = reader.GetInt32(0);
                        string name = reader.GetString(1);
                        string lastName = reader.GetString(2);
                        comboBox5.Items.Add(new ComboBoxItem(id, $"{name} {lastName}")); // Create a ComboBoxItem to hold ID and name
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при загрузке агентов: " + ex.Message);
            }
        }

        private decimal GetPriceFromRange(string priceRange)
        {
            if (string.IsNullOrEmpty(priceRange))
            {
                throw new ArgumentException("Цена не может быть пустой.");
            }

            string[] parts = priceRange.Split('-');
            if (parts.Length != 2)
            {
                throw new FormatException("Неправильный формат диапазона цены.");
            }

            if (decimal.TryParse(parts[0], out decimal minPrice) && decimal.TryParse(parts[1], out decimal maxPrice))
            {
                return (minPrice + maxPrice) / 2;
            }
            else
            {
                throw new FormatException("Неправильные значения в диапазоне цены.");
            }
        }

        private void Add_Click(object sender, EventArgs e)
        {
            string type = comboBox1.SelectedItem?.ToString();
            string priceRange = textBox3.Text; // Ensure to get price range from a relevant combobox
            string location = textBox2.Text; // Assuming location is inputted here
            string rooms = textBox4.Text; // Assuming number of rooms is inputted here
            string description = textBox1.Text; // Use textBox1 for description
            int agentId = ((ComboBoxItem)comboBox5.SelectedItem)?.ID ?? 0; // Get selected agent's ID

            if (string.IsNullOrEmpty(type) || string.IsNullOrEmpty(priceRange) || string.IsNullOrEmpty(location) || agentId == 0)
            {
                MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                return;
            }

            string query = "INSERT INTO Объект_недвижимости (Тип, Цена, Адрес, Описание, Статус, ID_агента, Количество_комнат) VALUES (@Тип, @Цена, @Адрес, @Описание, @Статус, @ID_агента, @Количество_комнат)";

            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(@" Data Source= DESKTOP-MGDIAP6; Initial catalog=agents; Integrated Security=True"))
                {
                    SqlCommand command = new SqlCommand(query, sqlConnection);
                    command.Parameters.AddWithValue("@Тип", type);
                    command.Parameters.AddWithValue("@Цена", GetPriceFromRange(priceRange)); // Ensure price range is correctly fetched
                    command.Parameters.AddWithValue("@Адрес", location); // Assuming this is a text box
                    command.Parameters.AddWithValue("@Описание", description);
                    command.Parameters.AddWithValue("@Статус", "Доступно"); // Set a default status
                    command.Parameters.AddWithValue("@ID_агента", agentId);
                    command.Parameters.AddWithValue("@Количество_комнат", rooms); // Add number of rooms

                    sqlConnection.Open();
                    command.ExecuteNonQuery();
                }

                MessageBox.Show("Объект недвижимости добавлен.");
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }

        private class ComboBoxItem
        {
            public int ID { get; }
            public string DisplayName { get; }

            public ComboBoxItem(int id, string displayName)
            {
                ID = id;
                DisplayName = displayName;
            }

            public override string ToString()
            {
                return DisplayName; // This is what will be shown in the combo box
            }
        }
    }
}
