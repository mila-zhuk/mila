﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class UserForm : Form
    {
        private int? userId; // ID пользователя, если редактируем
        SqlConnection sqlConnection = new SqlConnection(@" Data Source= DESKTOP-MGDIAP6; Initial catalog=agents; Integrated Security=True");

        public UserForm(int? id = null)
        {
            InitializeComponent();
            userId = id;

            if (userId.HasValue)
            {
                LoadUserData(userId.Value);
            }
        }

        private void LoadUserData(int id)
        {
            string query = "SELECT Email, Имя, Фамилия, Пароль, Роль FROM Пользователи WHERE ID = @ID";

            using (SqlCommand command = new SqlCommand(query, sqlConnection))
            {
                command.Parameters.AddWithValue("@ID", id);
                sqlConnection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    textBoxEmail.Text = reader["Email"].ToString();
                    textBoxUsername.Text = reader["Имя"].ToString();
                    textBox1.Text = reader["Фамилия"].ToString();
                    textBoxPassword.Text = reader["Пароль"].ToString();
                    comboBoxRole.SelectedItem = reader["Роль"].ToString();
                }

                sqlConnection.Close();
            }
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            if (userId.HasValue)
            {
                // Обновить существующего пользователя
                string query = "UPDATE Пользователи SET Email = @Email, Имя = @Имя, Фамилия = @Фамилия, Пароль = @Пароль, Роль = @Роль WHERE ID = @ID";

                using (SqlCommand command = new SqlCommand(query, sqlConnection))
                {
                    command.Parameters.AddWithValue("@ID", userId.Value);
                    command.Parameters.AddWithValue("@Email", textBoxEmail.Text);
                    command.Parameters.AddWithValue("@Имя", textBoxUsername.Text);
                    command.Parameters.AddWithValue("@Фамилия", textBox1.Text);
                    command.Parameters.AddWithValue("@Пароль", textBoxPassword.Text);
                    command.Parameters.AddWithValue("@Роль", comboBoxRole.SelectedItem.ToString());

                    sqlConnection.Open();
                    command.ExecuteNonQuery();
                    sqlConnection.Close();
                }
            }
            else
            {
                // Добавить нового пользователя
                string query = "INSERT INTO Пользователи (Email, Имя, Фамилия, Пароль, Роль) VALUES (@Email, @Имя, @Фамилия, @Пароль, @Роль)";

                using (SqlCommand command = new SqlCommand(query, sqlConnection))
                {

                    SqlCommand cmd1 = new SqlCommand(query, sqlConnection);
                    SqlParameter pr1 = new SqlParameter("@Email", textBoxEmail.Text);
                    SqlParameter pr2 = new SqlParameter("@Имя", textBoxUsername.Text);
                    SqlParameter pr3 = new SqlParameter("@Фамилия", textBox1.Text);
                    SqlParameter pr4 = new SqlParameter("@Пароль", textBoxPassword.Text);
                    SqlParameter pr5 = new SqlParameter("@Роль", comboBoxRole.SelectedItem.ToString());

                    cmd1.Parameters.Add(pr1);
                    cmd1.Parameters.Add(pr2);
                    cmd1.Parameters.Add(pr3);
                    cmd1.Parameters.Add(pr4);
                    cmd1.Parameters.Add(pr5);



                    sqlConnection.Open();
                    cmd1.ExecuteNonQuery();
                    sqlConnection.Close();
                }
            }

            DialogResult = DialogResult.OK;
            this.Close();
        }

        private void UserForm_Load(object sender, EventArgs e)
        {

        }
    }
}
