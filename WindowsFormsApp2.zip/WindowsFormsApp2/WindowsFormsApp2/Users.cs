﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Users : Form
    {
        public Users()
        {
            InitializeComponent();
            LoadUsers();
        }
        SqlConnection sqlConnection = new SqlConnection(@" Data Source= DESKTOP-MGDIAP6; Initial catalog=agents; Integrated Security=True");

        private void LoadUsers()
        {
            string query = "SELECT ID, Email, Имя, Фамилия, Пароль, Роль FROM Пользователи";

            using (SqlCommand command = new SqlCommand(query, sqlConnection))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;
            }
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            // Открыть форму для добавления пользователя
            UserForm userForm = new UserForm();
            if (userForm.ShowDialog() == DialogResult.OK)
            {
                LoadUsers(); // Обновить список пользователей
            }
        }

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // Получить ID выбранного пользователя
                int userId = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
                UserForm userForm = new UserForm(userId);
                if (userForm.ShowDialog() == DialogResult.OK)
                {
                    LoadUsers(); // Обновить список пользователей
                }
            }
            else
            {
                MessageBox.Show("Выберите пользователя для редактирования.");
            }
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int userId = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
                string query = "DELETE FROM Пользователи WHERE ID = @ID";

                using (SqlCommand command = new SqlCommand(query, sqlConnection))
                {
                    command.Parameters.AddWithValue("@ID", userId);
                    sqlConnection.Open();
                    command.ExecuteNonQuery();
                    sqlConnection.Close();
                }

                LoadUsers(); // Обновить список пользователей
            }
            else
            {
                MessageBox.Show("Выберите пользователя для удаления.");
            }
        }
    }
}
